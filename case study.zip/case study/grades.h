#include<stdio.h>
#ifndef GRADES_H
#define GRADS_H
void student(int SRN);
int grade(int SRN);
#endif